[
	[
		{"img":"../img/hot3.jpg","text":"Liquid Image 338 运动摄像眼镜"},
		{"img":"../img/hot4.jpg","text":"巴慕达 The Toaster 烤面包机"},
		{"img":"../img/hot5.jpg","text":"Osprey小鹰户外运动专业腰包"},
		{"img":"../img/hot6.jpg","text":"空气净化器里面学问多得惊呆你，你选对了吗？"},
		{"img":"../img/hot1.jpg","text":"怎么骑都不会累的智能自行车：云马 C1试骑体验"},
		{"img":"../img/hot2.jpg","text":"声音不是最优秀，但它形音完美的结合，足够打动人心"},
		{"img":"../img/hot7.jpg","text":"风光大片信手拈来！vivo X6Plus不只是快，还是一台拍照利器"},
		{"img":"../img/hot8.jpg","text":"到底有没有完美的iPhone手机配件，答案都在这里"}
	],
	[
		{"img":"../img/g3.jpg","text":"Liquid Image 338 运动摄像眼镜"},
		{"img":"../img/g4.jpg","text":"巴慕达 The Toaster 烤面包机"},
		{"img":"../img/g1.jpg","text":"Osprey小鹰户外运动专业腰包"},
		{"img":"../img/g2.jpg","text":"空气净化器里面学问多得惊呆你，你选对了吗？"},
		{"img":"../img/k1.jpg","text":"怎么骑都不会累的智能自行车：云马 C1试骑体验"},
		{"img":"../img/k2.jpg","text":"声音不是最优秀，但它形音完美的结合，足够打动人心"},
		{"img":"../img/k4.jpg","text":"风光大片信手拈来！vivo X6Plus不只是快，还是一台拍照利器"},
		{"img":"../img/k3.jpg","text":"到底有没有完美的iPhone手机配件，答案都在这里"}
	],
	[
		{"img":"../img/re3.jpg","text":"Liquid Image 338 运动摄像眼镜"},
		{"img":"../img/re4.jpg","text":"巴慕达 The Toaster 烤面包机"},
		{"img":"../img/re1.jpg","text":"Osprey小鹰户外运动专业腰包"},
		{"img":"../img/re2.jpg","text":"空气净化器里面学问多得惊呆你，你选对了吗？"},
		{"img":"../img/hot12.jpg","text":"怎么骑都不会累的智能自行车：云马 C1试骑体验"},
		{"img":"../img/hot9.jpg","text":"声音不是最优秀，但它形音完美的结合，足够打动人心"},
		{"img":"../img/hot10.jpg","text":"风光大片信手拈来！vivo X6Plus不只是快，还是一台拍照利器"},
		{"img":"../img/hot11.jpg","text":"到底有没有完美的iPhone手机配件，答案都在这里"}
	],
	[
		{"img":"../img/k1.jpg","text":"Liquid Image 338 运动摄像眼镜"},
		{"img":"../img/k3.jpg","text":"巴慕达 The Toaster 烤面包机"},
		{"img":"../img/g1.jpg","text":"Osprey小鹰户外运动专业腰包"},
		{"img":"../img/g3.jpg","text":"空气净化器里面学问多得惊呆你，你选对了吗？"},
		{"img":"../img/hot1.jpg","text":"怎么骑都不会累的智能自行车：云马 C1试骑体验"},
		{"img":"../img/hot5.jpg","text":"声音不是最优秀，但它形音完美的结合，足够打动人心"},
		{"img":"../img/hot7.jpg","text":"风光大片信手拈来！vivo X6Plus不只是快，还是一台拍照利器"},
		{"img":"../img/hot2.jpg","text":"到底有没有完美的iPhone手机配件，答案都在这里"}
	]
]