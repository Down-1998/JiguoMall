[
	[
		{"img":"img/kuwan01.jpg","text":"索尼 FDR-AXP55 摄像机","price":"￥499"},
		{"img":"img/kuwan01.jpg","text":"索尼 FDR-AXP55 摄像机","price":"￥498"},
		{"img":"img/kuwan01.jpg","text":"索尼 FDR-AXP55 摄像机","price":"￥497"},
		{"img":"img/kuwan01.jpg","text":"索尼 FDR-AXP55 摄像机","price":"￥496"},
		{"img":"img/kuwan01.jpg","text":"索尼 FDR-AXP55 摄像机","price":"￥495"},
		{"img":"img/kuwan01.jpg","text":"索尼 FDR-AXP55 摄像机","price":"￥494"},
		{"img":"img/kuwan01.jpg","text":"索尼 FDR-AXP55 摄像机","price":"￥493"},
		{"img":"img/kuwan01.jpg","text":"索尼 FDR-AXP55 摄像机","price":"￥492"}
	],
	[
		{"img":"img/kuwan02.jpg","text":"三星 HW-K950 家庭影院","price":"￥1247"},
		{"img":"img/kuwan02.jpg","text":"三星 HW-K950 家庭影院","price":"￥1246"},
		{"img":"img/kuwan02.jpg","text":"三星 HW-K950 家庭影院","price":"￥1245"},
		{"img":"img/kuwan02.jpg","text":"三星 HW-K950 家庭影院","price":"￥1244"},
		{"img":"img/kuwan02.jpg","text":"三星 HW-K950 家庭影院","price":"￥1243"},
		{"img":"img/kuwan02.jpg","text":"三星 HW-K950 家庭影院","price":"￥1242"},
		{"img":"img/kuwan02.jpg","text":"三星 HW-K950 家庭影院","price":"￥1241"},
		{"img":"img/kuwan02.jpg","text":"三星 HW-K950 家庭影院","price":"￥1248"}
	],
	[
		{"img":"img/kuwan03.jpg","text":"FOSSIL Q45 Pilot 智能手表 ","price":"￥36000"},
		{"img":"img/kuwan03.jpg","text":"FOSSIL Q45 Pilot 智能手表 ","price":"￥36001"},
		{"img":"img/kuwan03.jpg","text":"FOSSIL Q45 Pilot 智能手表 ","price":"￥36002"},
		{"img":"img/kuwan03.jpg","text":"FOSSIL Q45 Pilot 智能手表 ","price":"￥36003"},
		{"img":"img/kuwan03.jpg","text":"FOSSIL Q45 Pilot 智能手表 ","price":"￥36004"},
		{"img":"img/kuwan03.jpg","text":"FOSSIL Q45 Pilot 智能手表 ","price":"￥36005"},
		{"img":"img/kuwan03.jpg","text":"FOSSIL Q45 Pilot 智能手表 ","price":"￥36006"},
		{"img":"img/kuwan03.jpg","text":"FOSSIL Q45 Pilot 智能手表 ","price":"￥36007"}
	],
	[
		{"img":"img/kuwan04.jpg","text":"轻客 TF01 电单车:可折叠 智能变速","price":"￥13201"},
		{"img":"img/kuwan04.jpg","text":"轻客 TF01 电单车:可折叠 智能变速","price":"￥13202"},
		{"img":"img/kuwan04.jpg","text":"轻客 TF01 电单车:可折叠 智能变速","price":"￥13203"},
		{"img":"img/kuwan04.jpg","text":"轻客 TF01 电单车:可折叠 智能变速","price":"￥13204"},
		{"img":"img/kuwan04.jpg","text":"轻客 TF01 电单车:可折叠 智能变速","price":"￥13205"},
		{"img":"img/kuwan04.jpg","text":"轻客 TF01 电单车:可折叠 智能变速","price":"￥13206"},
		{"img":"img/kuwan04.jpg","text":"轻客 TF01 电单车:可折叠 智能变速","price":"￥13207"},
		{"img":"img/kuwan04.jpg","text":"轻客 TF01 电单车:可折叠 智能变速","price":"￥13208"}
	]
]